sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("display.testxkxkxkxkxkxk.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map